#include<string>
#include<iostream>
using namespace std;
int main(){
  	string s;
  	cin >> s;
  	cout << s[0];
}