#include<bits/stdc++.h>
using namespace std;
int main(){
    char c;
    c = 'A';
    cout << c;
    return 0;
}