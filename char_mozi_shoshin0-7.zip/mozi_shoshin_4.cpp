//https://atcoder.jp/contests/abc252/tasks/abc252_a
#include<bits/stdc++.h>
using namespace std;
int main(){
  	int n;
  	cin >> n;
    cout << char(n);
    return 0;
}