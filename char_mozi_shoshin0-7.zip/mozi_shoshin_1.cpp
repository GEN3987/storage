#include<bits/stdc++.h>
using namespace std;
int main(){
    char c;
    c = 'A'+1;
    cout << c;
    return 0;
}