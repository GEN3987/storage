//https://atcoder.jp/contests/abc252/tasks/abc252_a
#include<bits/stdc++.h>
using namespace std;
int main(){
  	int n;
  	cin >> n;
    char c;
  	c = n;
    cout << c;
    return 0;
}