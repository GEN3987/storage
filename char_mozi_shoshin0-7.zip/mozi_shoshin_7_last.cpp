#include<string>
#include<iostream>
using namespace std;
int main(){
  	int a;
  	string s;
  	cin >> s;
  	a = s.size() - 1;
  	cout << s[a];
}