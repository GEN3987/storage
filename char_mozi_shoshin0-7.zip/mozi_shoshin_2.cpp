#include<bits/stdc++.h>
using namespace std;
int main(){
    char c;
    c = 65;     //ASCIIコード
    cout << c;
    return 0;
}